/*
 * APRSlib - Library for APRS communication.
 * Created by galaSAT team, december 20016.
 *
 * http://www.galasat.com/
 *
 * Based on trackuino by EA5HAV Javi
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef aprslib_h
#define aprslib_h

#include "Arduino.h"
#include "config.h"
#include "afsk_avr.h"
#include "pin.h"
#include "config.h"
#include "ax25.h"

class APRS
{
  public:
    void begin(char* callsign);
    void aprs_send(char* aprstime, char* aprslatitude, char* aprslongitude, char* aprscourse, char* aprsspeed, char* aprscomment);
};
#endif
