/*
 * APRSlib - Library for APRS communication.
 * Created by galaSAT team, december 20016.
 *
 * http://www.galasat.com/
 *
 * Based on trackuino by EA5HAV Javi
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "aprslib.h"

char S_CALLSIGN[7];

void APRS::begin(char* callsign)
{
  strcpy(S_CALLSIGN, callsign);
  afsk_setup();
}

void APRS::aprs_send(char* aprstime, char* aprslatitude, char* aprslongitude, char* aprscourse, char* aprsspeed, char* aprscomment)
{
   struct s_address addresses[] = { 
    {D_CALLSIGN, D_CALLSIGN_ID},  // Destination callsign
    {"      ", S_CALLSIGN_ID},  // Source callsign (-11 = balloon, -9 = car)
#ifdef DIGI_PATH1
    {DIGI_PATH1, DIGI_PATH1_TTL}, // Digi1 (first digi in the chain)
#endif
#ifdef DIGI_PATH2
    {DIGI_PATH2, DIGI_PATH2_TTL}, // Digi2 (second digi in the chain)
#endif
  };

  strcpy(addresses[1].callsign, S_CALLSIGN);

  #ifdef DEBUG_AX25
    Serial.print(F("aprstime: "));
    Serial.println(aprstime);
    Serial.print(F("aprslatitude: "));
    Serial.println(aprslatitude);
    Serial.print(F("aprslongitude: "));
    Serial.println(aprslongitude);
    Serial.print(F("aprscourse: "));
    Serial.println(aprscourse);
    Serial.print(F("aprsspeed: "));
    Serial.println(aprsspeed);
    Serial.print(F("aprscomment: "));
    Serial.println(aprscomment);
  #endif

  ax25_send_header(addresses, sizeof(addresses)/sizeof(s_address));
  ax25_send_byte('/');                // Report w/ timestamp, no APRS messaging. $ = NMEA raw data
  //ax25_send_string("170915");         // 170915 = 17h:09m:15s zulu (not allowed in Status Reports)
  ax25_send_string(aprstime);         // 170915 = 17h:09m:15s zulu (not allowed in Status Reports)
  ax25_send_byte('h');
  //ax25_send_string("3822.20");     // Lat: 38deg and 22.20 min (.20 are NOT seconds, but 1/100th of minutes)
  ax25_send_string(aprslatitude);     // Lat: 38deg and 22.20 min (.20 are NOT seconds, but 1/100th of minutes)
  ax25_send_byte('/');                // Symbol table
  //ax25_send_string("00025.80");     // Lon: 000deg and 25.80 min
  ax25_send_string(aprslongitude);     // Lon: 000deg and 25.80 min
  ax25_send_byte('O');                // Symbol: O=balloon, -=QTH
  //ax25_send_string("0");             // Course (degrees)
  ax25_send_string(aprscourse);             // Course (degrees)
  ax25_send_byte('/');                // and
  //ax25_send_string("100");             // speed (knots)
  ax25_send_string(aprsspeed);             // speed (knots)
  //ax25_send_string("/COMMENT");     // Comment
  ax25_send_byte('/');
  ax25_send_string(aprscomment);     // Comment
  ax25_send_footer();

  ax25_flush_frame();                 // Tell the modem to go
}
